import google.generativeai as genai
from django.conf import settings
import json
import re
from ..models import MedicalReport

def generate_health_plans(profile):
    """
    Generate personalized workout and diet plans using Gemini based on HealthProfile.
    """
    genai.configure(api_key=settings.GEMINI_API_KEY)
    print("DEBUG: Initializing model models/gemini-flash-latest for health plans")
    model = genai.GenerativeModel("models/gemini-flash-latest")

    profile_data = f"""
    Age: {profile.age}
    Gender: {profile.gender}
    Weight: {profile.weight} kg
    Height: {profile.height} cm
    Activity Level: {profile.activity_level}
    Sugar Status: {profile.sugar_status}
    Smoker: {profile.smoker}
    Alcohol: {profile.alcohol}
    Sleep: {profile.sleep_hours} hours
    BP: {profile.blood_pressure}
    """

    prompt = f"""
    Act as a professional fitness coach and nutritionist.
    Based on this profile, generate a 7-day Health Plan.
    
    Profile:
    {profile_data}
    
    Provide the output in the following JSON format:
    {{
        "workout_plan": [
            {{ "day": "Day 1", "activities": ["ex1", "ex2"], "duration": "30 mins" }},
            ... for 7 days
        ],
        "diet_plan": [
            {{ "meal": "Breakfast", "options": ["Option 1", "Option 2"], "avoid": ["Sugar", "Fried"] }},
            {{ "meal": "Lunch", "options": ["Option 1", "Option 2"], "avoid": ["Oil"] }},
            {{ "meal": "Dinner", "options": ["Option 1", "Option 2"], "avoid": ["Heavy food"] }}
        ],
        "lifestyle_tips": ["Tip 1", "Tip 2"]
    }}
    
    Keep it extremely simple and easy to follow. Focus on home workouts.
    """

    try:
        response = model.generate_content(prompt)
        text = response.text
        
        # Parse JSON
        match = re.search(r"```json\s*(\{[\s\S]*?\})\s*```", text)
        if match:
            return json.loads(match.group(1))
        
        match = re.search(r"\{[\s\S]*\}", text)
        if match:
            return json.loads(match.group(0))

        return {"error": "Failed to parse AI plans."}
    except Exception as e:
        return {"error": str(e)}

def generate_gym_workout(profile, mode='normal'):
    """
    Generate a professional Gym-specific workout plan.
    Modes: 'normal' (maintenance), 'medical' (based on report issues)
    """
    genai.configure(api_key=settings.GEMINI_API_KEY)
    print(f"DEBUG: Initializing model models/gemini-flash-latest for gym workout ({mode})")
    model = genai.GenerativeModel("models/gemini-flash-latest")

    latest_report = MedicalReport.objects.filter(user=profile.user).order_by('-uploaded_at').first()
    report_context = ""
    if mode == 'medical' and latest_report:
        report_context = f"LATEST MEDICAL REPORT FINDINGS: {latest_report.conditions_notes}\nSUMMARY: {latest_report.summary}"

    profile_data = f"""
    Age: {profile.age}, Gender: {profile.gender}, Weight: {profile.weight}kg, Activity: {profile.activity_level}, Sugar: {profile.sugar_status}
    """

    if mode == 'medical':
        prompt_goal = "HEALING & SAFETY. Adapt activities to address risks found in the medical report (e.g. low impact if joint issues, steady cardio if BP high)."
    else:
        prompt_goal = "BODY MAINTENANCE & STRENGTH. Focus on general fitness, muscle tone, and metabolism."

    prompt = f"""
    Act as a professional Gym Trainer. Create a 7-day Gym Workout Plan.
    MODE: {mode.upper()}
    GOAL: {prompt_goal}
    
    Profile: {profile_data}
    {report_context}
    
    The plan must use GYM EQUIPMENT (Barbells, Dumbbells, Machines, Cables).
    
    Provide output in JSON:
    {{
        "title": "{mode.capitalize()} Gym Routine",
        "description": "7-day customized routine for {mode} needs.",
        "days": [
            {{
                "day": "Monday",
                "focus": "...",
                "exercises": [
                    {{ "name": "...", "sets": "3", "reps": "12", "tip": "..." }}
                ]
            }},
            ...
        ]
    }}
    Include 1-2 rest days.
    """

    try:
        response = model.generate_content(prompt)
        match = re.search(r"```json\s*(\{[\s\S]*?\})\s*```", response.text)
        if match:
            return json.loads(match.group(1))
        
        match = re.search(r"\{[\s\S]*\}", response.text)
        if match:
            return json.loads(match.group(0))

        return {"error": "AI could not generate gym plan."}
    except Exception as e:
        return {"error": str(e)}

def generate_home_workout(profile, mode='normal'):
    """
    Generate a professional Home-specific workout plan.
    Modes: 'normal' (maintenance), 'medical' (based on report issues)
    """
    genai.configure(api_key=settings.GEMINI_API_KEY)
    model = genai.GenerativeModel("models/gemini-flash-latest")

    latest_report = MedicalReport.objects.filter(user=profile.user).order_by('-uploaded_at').first()
    report_context = ""
    if mode == 'medical' and latest_report:
        report_context = f"LATEST MEDICAL REPORT FINDINGS: {latest_report.conditions_notes}\nSUMMARY: {latest_report.summary}"

    profile_data = f"""
    Age: {profile.age}, Gender: {profile.gender}, Weight: {profile.weight}kg, Activity: {profile.activity_level}, Sugar: {profile.sugar_status}
    """

    if mode == 'medical':
        prompt_goal = "HEALING & SAFETY AT HOME. Adapt activities to address risks found in its report using NO heavy equipment. Focus on bodyweight and safe stretches."
    else:
        prompt_goal = "HOME BODY MAINTENANCE & TONE. Focus on general fitness using bodyweight or minimal household items."

    prompt = f"""
    Act as a professional Home Fitness Coach. Create a 7-day Home Workout Plan.
    MODE: {mode.upper()}
    GOAL: {prompt_goal}
    
    Profile: {profile_data}
    {report_context}
    
    The plan must NOT require heavy gym equipment. Focus on bodyweight, resistance bands, or household items.
    
    Provide output in JSON:
    {{
        "title": "{mode.capitalize()} Home Routine",
        "description": "7-day customized home routine for {mode} needs.",
        "days": [
            {{
                "day": "Monday",
                "focus": "...",
                "exercises": [
                    {{ "name": "...", "sets": "3", "reps": "12", "tip": "..." }}
                ]
            }},
            ...
        ]
    }}
    """

    try:
        response = model.generate_content(prompt)
        match = re.search(r"```json\s*(\{[\s\S]*?\})\s*```", response.text)
        if match:
            return json.loads(match.group(1))
        
        match = re.search(r"\{[\s\S]*\}", response.text)
        if match:
            return json.loads(match.group(0))

        return {"error": "AI could not generate home plan."}
    except Exception as e:
        return {"error": str(e)}
